In this assignment, the enhanced features has been implemented.
